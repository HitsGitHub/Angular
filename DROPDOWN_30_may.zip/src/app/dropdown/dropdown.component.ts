import { Component, OnInit } from '@angular/core';
import { ServiceJSONService } from '../service-json.service';
import { Subscriber } from 'rxjs';

@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css']
})
export class DropdownComponent implements OnInit {
  Brands = [];
  models = [];
  selectedBrand : string;
  public CarBrand : any [] = [] ;
  public finaldata: any [] = [];
  xyz : any = [];

  tempModels : any  = [];
  tempModelName : any = [];
  constructor(private jsondata : ServiceJSONService ) { }

  ngOnInit() {

    this.jsondata.getJSONData().subscribe(data=>{
      this.xyz = data;
      for (let i = 0; i < data.length; i++) {

        for(let j=0;j<data[i].car.length;j++){

          const element = data[i].car[j].name;
          this.Brands.push(element);
          
        }
        
        // console.log("elementtt",element);
        
        // this.xyz = data;
        // this.Brands.push(element); 
      }

     
      
   });
  }
  changeModels($event){
    this.finaldata.splice(0);
    this.finaldata = this.CarBrand.filter(x => x.did == $event.target.value);
    this.models.push(this.finaldata);
  }
}
