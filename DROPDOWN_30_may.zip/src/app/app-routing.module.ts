import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DropdownComponent } from './dropdown/dropdown.component';

const routes: Routes = [
{ path : '',redirectTo :'dropdown',pathMatch : 'full'},
{ 
  path: 'dropdownDemo', 
  component:DropdownComponent,
},
{ path: '**',redirectTo:'dropdownDemo'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
