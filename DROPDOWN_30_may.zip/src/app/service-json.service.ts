import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ServiceJSONService {
  items = [];
  constructor(private http : HttpClient) {
    this.getJSONData().subscribe(data=>{
      this.items = data;
      // console.log("itesmmss",this.items);
      
    });
  }
  public getJSONData():Observable<any>{
    return this.http.get("assets/car_info.json");
  }

}
