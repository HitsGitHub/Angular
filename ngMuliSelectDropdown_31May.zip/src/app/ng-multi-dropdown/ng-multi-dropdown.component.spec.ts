import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NgMultiDropdownComponent } from './ng-multi-dropdown.component';

describe('NgMultiDropdownComponent', () => {
  let component: NgMultiDropdownComponent;
  let fixture: ComponentFixture<NgMultiDropdownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NgMultiDropdownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NgMultiDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
