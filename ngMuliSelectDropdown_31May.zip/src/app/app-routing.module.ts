import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NgMultiDropdownComponent} from './ng-multi-dropdown/ng-multi-dropdown.component';
const routes: Routes = [
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
