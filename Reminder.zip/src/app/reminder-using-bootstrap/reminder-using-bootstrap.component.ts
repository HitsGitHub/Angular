import { Component, OnInit } from '@angular/core';
import { Time } from '@angular/common';
import { FormArray, FormGroup, FormBuilder} from '@angular/forms';
@Component({
  selector: 'app-reminder-using-bootstrap',
  templateUrl: './reminder-using-bootstrap.component.html',
  styleUrls: ['./reminder-using-bootstrap.component.css']
})
export class ReminderUsingBootstrapComponent implements OnInit {

  myForm : FormGroup;


  taskStatus =  [
  {id: 1, status: "Started"}, 
  {id: 2, status: "Late" },
  {id: 3, status:"Today" },
  {id: 4, status: "Upcoming"},
  {id: 5, status: "Completed"}
] 

  saveData = [];
  
  public id: number;
  public task: string;

  public time : Time;
  public rows: Array<{id: number, task: string,time:Time}> = [];

 
  // buttonClicked() {
  // this.rows.push( {id: this.id, task : this.task, time:this.time } );

  //   //if you want to clear input
  //  this.id = null;
  //   this.task = null;

  //   this.time = null;
  // }
  constructor(private fb : FormBuilder) { }

  ngOnInit() {

    this.myForm = this.fb.group({
      ctask : "",
      cstatus : "",
    })
  }

  onChange(statusindex){
    console.log(statusindex);
  }
  onSubmit(){
 
  const cTime = new Date().toLocaleString();
  console.log(cTime);
  
   

    this.saveData.push (this.myForm.value);
    console.log(this.saveData);

    
    
  }
}
