import { Component, OnInit } from '@angular/core';
import { ServiceJSONService } from '../service-json.service';
import { Subscriber } from 'rxjs';

@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css']
})
export class DropdownComponent implements OnInit {
  Brands = [];
  selectedBrand = 0;
  selectedModel = 0;
  models = [];
  colors = [];
  CarBrand : any [] ;
  constructor(private jsondata : ServiceJSONService ) { }

  ngOnInit() {
    this.jsondata.getJSONData().subscribe(data=>{
      
      for(let i = 0; i < data.length;i++){
        this.Brands.push(data[i].CAR)
        console.log("Brands",this.Brands);
        
       }
     for(let i = 0 ; i< this.Brands.length; i++){
         console.log();
         
       }  
        /* for(let i = 0; i <= data[i].model.length;i++){
       
          console.log(data[i].model[i]);
          this.models.push("models",data[i].model[i]);
       } */
       
     });
  }
  getBrand(){
    return this.CarBrand;
    /* this.jsondata.getJSONData().subscribe(data=>{
      
      for(let i = 0; i < data.length;i++){
        return this.Brands.push(data[i].car)
       }
  }) */
}
  getModel(){
    this.jsondata.getJSONData().subscribe(data => {
      this.models = data.model;

    })

  }
  onSelectBrand(brand_id: number){
 
  }
  onSelectModel(model_id: number){
    this.selectedModel = model_id;
    
  }
}
