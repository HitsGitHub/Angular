import { Component, OnInit } from '@angular/core';
import { FormArray,FormControl,FormGroup,FormBuilder} from '@angular/forms';

@Component({
  selector: 'app-dynamic-checkbox',
  templateUrl: './dynamic-checkbox.component.html',
  styleUrls: ['./dynamic-checkbox.component.css']
})
export class DynamicCheckboxComponent implements OnInit {
  myForm : FormGroup;
  musicPreferences = [
    { id: 1, genre: 'Pop' },
    { id: 2, genre: 'Rock' },
    { id: 3, genre: 'Techno' },
    { id: 4, genre: 'Hiphop' },
  ];

  constructor(private fb : FormBuilder) { 
       // Create a FormControl for each available music preference, initialize them as unchecked, and put them in an array
       const formControls = this.musicPreferences.map(control => new FormControl(false));

       // Create a FormControl for the select/unselect all checkbox
       const selectAllControl = new FormControl(false);
     
       // Simply add the list of FormControls to the FormGroup as a FormArray, add the selectAllControl separetely
       this.myForm = this.fb.group({
         musicPreferences: new FormArray(formControls),
         selectAll: selectAllControl
       });
  }
  ngOnInit() {
    this.onChanges();
  }
  onChanges():void{
     // Subscribe to changes on the selectAll checkbox
     this.myForm.get('selectAll').valueChanges.subscribe(bool => {
      this.myForm
        .get('musicPreferences')
        .patchValue(Array(this.musicPreferences.length).fill(bool), { emitEvent: false });
    });

    // Subscribe to changes on the music preference checkboxes
    this.myForm.get('musicPreferences').valueChanges.subscribe(val => {
      const allSelected = val.every(bool => bool);
      if (this.myForm.get('selectAll').value !== allSelected) {
        this.myForm.get('selectAll').patchValue(allSelected, { emitEvent: false });
      }
    });
  }
  submitt(){

  }

}
