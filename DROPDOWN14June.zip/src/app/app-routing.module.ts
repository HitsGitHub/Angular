import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import{ DynamicCheckboxComponent} from './dynamic-checkbox/dynamic-checkbox.component';
const routes: Routes = [{
 path:'checkbox', component:DynamicCheckboxComponent
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
