import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import {Router} from '@angular/router';
import {ToastrService, ToastRef, Toast} from 'ngx-toastr'; 

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  lstData: any;

  check_validation() {

    this.loginForm = this.fb.group({
      mail: ['', Validators.compose([Validators.required, Validators.email])],
      pass: ['', Validators.required],
    });
  }
  constructor(private fb : FormBuilder,private toast:ToastrService,private route:Router ) { 
  }
  ngOnInit() {
    this.check_validation();
    
   }
  submitForm($ev, value: any) {
    for (let val in this.loginForm.controls) {
      this.loginForm.controls[val].markAsTouched();
    };
    if (this.loginForm.valid) {
      const form_data = this.loginForm.value;
     // console.log(form_data);
    };
  }
  login(){
    
    let mailFromLogin = this.loginForm.get("mail").value;
    let passFromLogin = this.loginForm.get("pass").value;
    let storedData = JSON.parse(localStorage.getItem("Data"));
    console.log(storedData);

    for(var i = 0; i< storedData.length;i++){
      if(storedData[i].mail == mailFromLogin && storedData[i].pass == passFromLogin ){          
       this.route.navigate(['/dashboard']);
       this.toast.success("Welcome "+storedData[i].name);
      }
   }

  }
    // var x = JSON.parse(localStorage.getItem("ObjectData"));

    // if(this.loginForm.get("mail").value == x.mail && this.loginForm.get("pass").value == x.pass)
    // {
    //  this.toast.success("Login Successful!!!");
    //  this.route.navigate(['dashboard']);
    // }
    // else{
    //   this.toast.warning("Login Fail");
    // }
}
