import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { CustomValidators } from 'ng2-validation';
import {ToastrService, Toast} from 'ngx-toastr';
import {Router} from '@angular/router';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  registerForm : FormGroup;
  regData = [];
  constructor(private fb : FormBuilder,private toast:ToastrService,private route:Router) {

    let password = new FormControl(null, Validators.compose([Validators.required,Validators.pattern['^[a-zA-Z0-9]{6,10}$']]));
    let confirm_password = new FormControl(null, Validators.compose([Validators.required, Validators.pattern['^[a-zA-Z0-9]{6,10}$'],CustomValidators.equalTo(password)]));

    this.registerForm = this.fb.group({
      name :['' , Validators.required, Validators.pattern['^[a-zA-Z \-\']+']],
      bod : ['', Validators.required],
      add :['', Validators.required],
      mono  :[null, Validators.compose([Validators.required, Validators.pattern['[0-9]*{9}']])],
      gender :['', Validators.required],
      mail: ['', Validators.compose([Validators.required, Validators.email,Validators.pattern['[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$']])],
      pass : password,
      cpass : confirm_password,
    });
   }
  ngOnInit() {

  }
  submitForm($ev, value: any) {
    for (let val in this.registerForm.controls) {
      this.registerForm.controls[val].markAsTouched();
    };
    if (this.registerForm.valid) {

        var dataObject= this.registerForm.value;
        var array = JSON.parse(localStorage.getItem('Data') || '[]');
        array.push(dataObject);
        localStorage.setItem('Data', JSON.stringify(array));
        this.route.navigate(['/login']);

        /* ar store=this.registerForm.value;
        this.regData.push(store);
        localStorage.setItem('ARAYDATA',JSON.stringify(this.regData));
        console.log(this.regData);
        this.toast.success("Data Stored Successsfully");
        this.route.navigate(['/login']);
        */
      
    }
  }
  DuplicateEmail(){
    let storedData = JSON.parse(localStorage.getItem("Data"));
    let mailFromRegi = this.registerForm.get('mail').value;
    for(var i = 0; i< storedData.length;i++){
      if(storedData[i].mail == mailFromRegi){
        this.registerForm.value('mail').focus();
        this.toast.warning("Email already Exist please use Another Email");        
      }  
    }
  }
} 
