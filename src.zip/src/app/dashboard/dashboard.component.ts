import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  retrive:string;
  constructor(private route:Router) { }
  myNames = [];
  myEmail = [];
  myDOB = [];
  myMobile = [];
  myGender = [];
  myAdd = [];
  storedData = [];
  ngOnInit() {
    this.retriveData();
  }

  retriveData(){
    this.storedData = JSON.parse(localStorage.getItem("Data"));
    
     console.log(this.storedData);
     for(let i = 0; i < this.storedData.length; i++){
      this.myNames[i] = this.storedData[i].name;
      this.myEmail[i] = this.storedData[i].mail;
      this.myDOB[i] =this.storedData[i].bod;
      this.myMobile[i] = this.storedData[i].mono;
      this.myGender[i] = this.storedData[i].gender;
      this.myAdd[i] = this.storedData[i].add;

      console.log(this.storedData);
     }
 
  }
  deleteUser(user){

  }

}