import { Component, OnInit } from '@angular/core';
import {Router} from'@angular/router';
import { FormBuilder, FormGroup,Validators, RequiredValidator} from '@angular/forms';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
  editform:FormGroup;
  
  constructor(private fb:FormBuilder, private route:Router) { }

  ngOnInit() {
    let emailEdit = localStorage.getItem('mail');
    if(emailEdit){
      this.route.navigate(['/dashboard']);
      return;
    }
    else{
      alert('Invalid Email')
      this.route.navigate(['/dashboard']);
      return;
    }
    this.editform = this.fb.group({
      id:[],
      email:['',Validators.required],
      name:['',Validators.required],
      dob:['',Validators.required],
      mobile:['',Validators.required],
      gender:['',Validators.required],
      address:['',Validators.required]
    });
  }
  onSubmit(){

  }

}
