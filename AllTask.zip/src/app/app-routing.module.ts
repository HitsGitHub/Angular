import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LoginComponent} from './login/login.component'
import {RegistrationComponent} from './registration/registration.component'
import {DashboardComponent} from './dashboard/dashboard.component';
import {AuthGuard} from './auth.guard';
import { ReminderUsingBootstrapComponent } from './reminder-using-bootstrap/reminder-using-bootstrap.component';
import { MultipledropdownComponent } from './multipledropdown/multipledropdown.component';

const routes: Routes = [
  
  { 
    path: '', 
    redirectTo: 'login', 
    pathMatch: 'full',
  },
  { 
    path: 'login', 
    component:LoginComponent, canActivate: [AuthGuard]
  },
  { path: 'register/:ind', component: RegistrationComponent },
  { path: 'register', component: RegistrationComponent }, 
  { path: 'dashboard', component: DashboardComponent},
  { path : 'dashboard /:ind', component:DashboardComponent},

  { path: 'reminder', component:ReminderUsingBootstrapComponent},
  { 
    path: 'dropdown', 
    component:MultipledropdownComponent,
  },
  { path: '**',redirectTo:'login'},
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
