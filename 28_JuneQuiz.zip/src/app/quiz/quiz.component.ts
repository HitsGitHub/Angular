import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,FormControl} from '@angular/forms'
import { QuizDataService} from '../quiz-data.service';
import {Router,ActivatedRoute} from '@angular/router'
@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {
  quizForm : FormGroup;
  title = "Quiz Wizard"
  Questions : any []
  Answers : any[]
  Types : any[]
  correctIndex : []
  Ans = []
    count : number ;
      tempQuestions = [];
      questionsToDisplay = [];
      x : number;

  constructor(private quizdataservice: QuizDataService, private fb : FormBuilder,public route: ActivatedRoute, public router: Router) 
  {
   this.quizForm = new FormGroup({
    
   })
  }
  ngOnInit() {
    this.quizdataservice.getQuizdata().subscribe(data=>{
      this.Questions = data.questions
      
      for (let i = 0; i < this.Questions.length; i++) {
         this.tempQuestions.push(this.Questions[i])
      }

console.log("t",this.tempQuestions[0]);

 
      for (let i = 0; i < 5; i++) {
        this.questionsToDisplay.push(this.tempQuestions[i])
        
      }
      this.count = 5;
      this.x = this.count;

      
    })
      
  // console.log("QTD",this.questionsToDisplay);
  
       
    
   }

   nextQuestions(i){
     console.log(i);
     
      let l = this.questionsToDisplay.length;
      this.questionsToDisplay = [];

    let  c =0;
    for (let i=0; i<5; i++) {
       
         this.questionsToDisplay.push(this.tempQuestions[l])
        l++;
       
    }

    console.log(this.questionsToDisplay);
    

   }





  onSubmit(){
    console.log(this.quizForm.value)
  }
  getQuestions(){
    return this.Questions
  }
  getAnswer(){
    return this.Answers
  }
  getTypes(){
    return this.Types
  }
  changeLabelName(lbl, val) {
    document.getElementById(lbl).innerHTML = val;
  }  
  gettingQuestioType(){
    
  }
  check(v, i){

  }
}
