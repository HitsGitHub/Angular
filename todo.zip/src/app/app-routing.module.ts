import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';
import { TodoComponent } from './todo/todo.component';

const routes: Routes = [
  {
    path : '', pathMatch : 'full',redirectTo : 'reminder'
  },
  {
    path: 'reminder', component:TodoComponent
  },
  {
    path: '**', redirectTo:'reminder'
  },
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
