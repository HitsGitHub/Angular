import { Component, OnInit,ElementRef, ViewChild } from '@angular/core';
import {FormBuilder,FormGroup} from '@angular/forms';
import { from } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {
  myForm: FormGroup;
  saveData = [];
  complete : boolean = false;
  isDisabled: boolean;
  checkarray: any[] = [];
  public selectedId : any;
  public selectedstatus: any[] = [];   
  public table_data: any;

  taskStatus = [
    { id: 1, status: "Started" },
    { id: 2, status: "Late" },
    { id: 3, status: "Today" },
    { id: 4, status: "Upcoming" },
    { id: 5, status: "Completed" }
  ]
  constructor(private fb: FormBuilder) { }
today;
  ngOnInit() {
    this.myForm = this.fb.group({
      ctask: "",
      cstatus: "",
     })
  }
  onSubmit() {
     this.today = Date.now();
  let fixedTimezone = this.today;
    this.saveData.push(this.myForm.value);
    //console.log(this.saveData);
  }

  todoClear(){
    this.taskStatus.splice(0);
  }

  /* ----------CURENT TIME ---------*/
  

  /* -------- Getting Status -------- */
  onChange(selectedDropValue:any) {
    
    if(selectedDropValue == "Completed"){
      
    }
    else{
      //console.log("valueee",selectedDropValue);
   }
  }

  changeStatus(e, id) {
 
     this.saveData[id].cstatus = "completed";
    this.saveData[id].time = "virendra";
    console.log(this.saveData);
    
     
    }







    /* var status = e.target.checked;
    console.log("Statusss",status);
    var checkbox = document.getElementById("chk");
    console.log("aa",checkbox);
    var text = document.getElementById("text");
    if (e == true){
      text.style.display="Completed";
    } else {
      text.style.display = "none";
    }
 */
    /* this.selectedstatus.changeStatus(id, status).subscribe(result => {
        if (status)
            this.notify.success(this.l('AddedAsKeyPeople'));
        else
            this.notify.success(this.l('RemovedFromKeyPeople'));

    }); */

  
  /* GENERATE PDF REPORT START */
  /* @ViewChild('reportContent') reportContent: ElementRef;

  downloadPdf() {
    const doc = new jsPDF('p', 'mm', 'a4');
    const specialElementHandlers = {
      '#editor': function (element, renderer) {
        return true;
      }
    };
    const content = this.reportContent.nativeElement;
    doc.fromHTML(content.innerHTML, 15, 10, {
      
      'position': 'Landscape',
      'width': 0,
      'elementHandlers': specialElementHandlers
    });
    doc.save('ReminderReport' + '.pdf');
  }
 */

}
