import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { QuizComponent } from './quiz/quiz.component';
import { HttpClientModule} from '@angular/common/http';
import { FormsModule,ReactiveFormsModule} from '@angular/forms';
import { RouterModule} from '@angular/router';
import { DynamicformComponent } from './dynamicform/dynamicform.component';
import { RadiobuttonTestComponent } from './radiobutton-test/radiobutton-test.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SimpleRadioGroupComponent } from './simple-radio-group/simple-radio-group.component';
import { FinalQuizComponent } from './final-quiz/final-quiz.component';

@NgModule({
  declarations: [
    AppComponent,
    QuizComponent,
    DynamicformComponent,
    RadiobuttonTestComponent,
    SimpleRadioGroupComponent,
    FinalQuizComponent
  ],
  imports: [
    BrowserModule,HttpClientModule,RouterModule,
    AppRoutingModule,FormsModule,ReactiveFormsModule, 
    BrowserAnimationsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { 
  
}
