import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators, FormArray } from '@angular/forms'
import { QuizDataService } from '../quiz-data.service';

@Component({
  selector: 'app-radiobutton-test',
  templateUrl: './radiobutton-test.component.html',
  styleUrls: ['./radiobutton-test.component.css']
})
export class RadiobuttonTestComponent implements OnInit {
  quizForm: FormGroup;
  title = "Quiz Wizard"
  Questions: any
  Answers : any
  typeOfQuestion : any;
  radioQues = [];
  Ans = [];

  constructor(private quizdataservice: QuizDataService,
    private fb: FormBuilder) {
      
      this.quizForm = this.fb.group({
        btn_radio: ['',Validators.required]
      })
     
  }
  ngOnInit() {
    
    this.quizdataservice.getQuizdata().subscribe(data => {
      this.Questions = data.questions
      for (let i = 0; i < this.Questions.length; i++ ) {
        if(this.Questions[i].types == 'radio'){
          
          this.Ans.push(this.Questions[i].answers)
          this.radioQues.push(this.Questions[i].question)
        }
        this.Answers = this.Ans
        this.typeOfQuestion = this.radioQues
      }
    },
      error => {
        console.log("Data Not Fatch", error)
      })
  }
  
  onRadioBtnChange(value:string,i,isChecked : boolean) {    
    console.log(value);
    console.log(i);
    
    const radioButnFormArray = <FormArray>this.quizForm.controls.btn_radio;
    if (isChecked) {
      radioButnFormArray.push(new FormControl(value));
    } else {
      let index = radioButnFormArray.controls.findIndex(x => x.value == value)
      radioButnFormArray.removeAt(index);
    }
  }
  onSubmit() {
    console.log(this.quizForm.value);
    localStorage.setItem("QuizAnswer", JSON.stringify(this.quizForm.value));
  } 

}
