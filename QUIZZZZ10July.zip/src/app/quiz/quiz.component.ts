import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators, FormArray } from '@angular/forms'
import { QuizDataService } from '../quiz-data.service';

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {
  quizForm: FormGroup;
  title = "Quiz Wizard"

  Questions: any
  Answers = []
  typeOfAnswer = []
  QueType = [];
  Ans = [];
  x: number = 0
  ans = [];
 

  constructor(private quizdataservice: QuizDataService,
    private fb: FormBuilder) {
  }

  ngOnInit() {
    this.quizForm = this.fb.group({
      btn_radio:this.fb.array ([Validators.required]),
      txtbox:this.fb.array ([Validators.minLength(3)]),
      val_check: this.fb.array ([Validators.required]),
      
    })
    this.quizdataservice.getQuizdata().subscribe(data => {
      this.Questions = data.questions
      
      for (let i = 0; i < 5; i++ , this.x++) {
        this.Ans.push(this.Questions[i].answers)
        this.QueType.push(this.Questions[i].types)
      }
     this.Answers = this.Ans
     this.typeOfAnswer = this.QueType

    },
      error => {
        console.log("Data Not Fatch", error)
      })
  }
 
  temp = [];
  nextQuestions() {
    this.Ans = []
    this.QueType = []
    this.temp = []
    let count = 0;

    for (let i = this.x; i < this.Questions.length; i++ , this.x++ , count++) {
      if (count <= 4) {
        this.temp.push(this.Questions[i])
        this.Ans.push(this.Questions[i].answers)
        this.QueType.push(this.Questions[i].types)
      }
      else {
        this.Questions = this.temp
        this.Answers = this.Ans
        this.typeOfAnswer = this.QueType
        count = 0
        continue
      }
      console.log("x", this.x)
     
    }
  }

  /* onRadioBtnChange(value:string,id:number,isChecked : boolean) {    
    
     const radioButnFormArray = <FormArray>this.quizForm.controls.btn_radio;
    if (isChecked == true) {
      radioButnFormArray.push(new FormControl(value));
      
    } else {
      let index = radioButnFormArray.controls.findIndex(x => x.value == value)
      radioButnFormArray.removeAt(index);
    }
   }
 */
  selectedChBox(value: string, id:number,isChecked: boolean) {
    const ChkBoxFormArray = <FormArray>this.quizForm.controls.val_check;
    if (isChecked == true) {
      ChkBoxFormArray.push(new FormControl(value));
      
    } else {
      let index = ChkBoxFormArray.controls.findIndex(x => x.value == value)   
      ChkBoxFormArray.removeAt(index);
       console.log("CHK",ChkBoxFormArray);

    }
  }

  onSubmit() {
    console.log(this.quizForm.value);
    localStorage.setItem("QuizAnswer", JSON.stringify(this.quizForm.value));
  }
  saveText(evt){    
    if(evt){
      const textValue = <FormArray>this.quizForm.controls.txtbox;
      textValue.push(new FormControl(evt));
    }
    else{
      
    }
  }
  private _prevSelected: any;
 indices = [];
  handleChange(evt,j) {
    // var radioButnFormArray = <FormArray>this.quizForm.controls.btn_radio;
    var target = evt.target;

    console.log("evt.target",evt.target);
    
    if (target.checked) {
      
       // while (radioButnFormArray.length !== 0) {
      //   radioButnFormArray.removeAt(0)
      // }
      if(this.indices.length){
        for(let i=0;i<this.indices.length;i++){
          if(this.indices[i]== j){
            // radioButnFormArray.removeAt(i);
            // radioButnFormArray.push(new FormControl(target.value));    
            this.ans.splice(i,1,target.value)  
            this.indices.splice(i,1,j)
            return
          }else{
            alert();
            if(this.indices[i+1] === undefined){
              alert("undefined")
              this.indices.push(j)
              this.ans.push(target.value)
              return;
            }else{
              this.ans.splice(i+1,1,target.value);
              this.indices.splice(i,1,j);
              return;
            }
          }
        }
      }else{  
        alert("else")
        this.indices.push(j)
        this.ans.push(target.value)
        // radioButnFormArray.push(new FormControl(target.value));      

      }
      
      this._prevSelected = target;
      // this.indices.push(j);  
    } else {
      // let index = radioButnFormArray.controls.findIndex(x => x.value == target.value)
      // radioButnFormArray.removeAt(index);
    }
  }
}
