import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder,Validators} from '@angular/forms'
import {QuizDataService} from '../quiz-data.service'
@Component({
  selector: 'app-simple-radio-group',
  templateUrl: './simple-radio-group.component.html',
  styleUrls: ['./simple-radio-group.component.css']
})
export class SimpleRadioGroupComponent implements OnInit {
  public fruitsForm: FormGroup;
  public fruits = ["Apple", "Mango", "Banana", "Orange","Kiwi"];
  public foods = ["Pizza","Chiness","Burgger"];
  public newModel: FruitData;
  public model: FruitData;

  public entries = [
    {
      id: 1,
      description: 'entry 1'
    },
    {
        id: 2,
        description: 'entry 2'
    },
  ]
  
  constructor(private _formBuilder: FormBuilder,private jsondata: QuizDataService) { 
      // Simulate getting data from external service
      
      this.model = {
      favFruit: this.fruits[0],
      favFood : this.foods[0]
    };
    this.createForm();
  }
  private createForm() {
    this.fruitsForm = this._formBuilder.group({
        favoriteFruit: ["", Validators.required],
        favoriteFood:["",Validators.required]
    });

    this.fruitsForm.setValue({
        favoriteFruit: this.model.favFruit,
        favoriteFood : this.model.favFood,
    });
  }

  ngOnInit() {
    this.jsondata.getQuizdata().subscribe(data=>{
      const QuizData = data.questions;
      console.log("QuizData",QuizData);
    })
  }

  selectedEntry;
  onSelectionChange(entry) {
    this.selectedEntry = entry;
  }
}
export class FruitData {
  public favFruit: string;
  public favFood : string;
}
