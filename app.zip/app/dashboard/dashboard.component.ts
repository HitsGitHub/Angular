import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  retrive:string;
  constructor(private route:Router) { }
  myNames = [];
  myEmail = [];
  myDOB = [];
  myMobile = [];
  myGender = [];
  myAdd = [];
  storedData = [];
  ngOnInit() {
    this.retriveData();
  }
  public popoverTitle: string = 'Delete this Record??';
  public popoverMessage: string = 'Record will be Deleted permenantly ';
  public confirmClicked: boolean = false;
  public cancelClicked: boolean = false;

  retriveData(){
    this.storedData = JSON.parse(localStorage.getItem("Data"));
    
     console.log(this.storedData);
     for(let i = 0; i < this.storedData.length; i++){
      this.myNames[i] = this.storedData[i].name;
      this.myEmail[i] = this.storedData[i].mail;
      this.myDOB[i] =this.storedData[i].bod;
      this.myMobile[i] = this.storedData[i].mono;
      this.myGender[i] = this.storedData[i].gender;
      this.myAdd[i] = this.storedData[i].add;
      console.log(this.storedData);
     }
 
  }
  deleteUser(id){
    //   for(let i = 0; i < d.length; ++i){
      //     if (d[i].id === id) {
        //         d.slice(i,1);
        //     }
        // }
        let d :. [] = JSON.stringify( localStorage.getItem("Data"));
         
        for(let i = 0; i<d.length;i++){
          if(id== i){
            
          }
        }
    
  }
  editUser(i){
    this.route.navigate(['/register', {index:i}]);
   


  }
  logout(){
    this.route.navigate(['/login']);
  }
}