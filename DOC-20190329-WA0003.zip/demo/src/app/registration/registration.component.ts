import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { CustomValidators } from 'ng2-validation';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  registerForm : FormGroup;
  

  // // validation(){
  // //   this.registerForm = this.fb.group({
  // //     name :['' , Validators.required],
  // //     bod : ['', Validators.required],
  // //     add :['', Validators.required],
  // //     mono :['', Validators.required],
  // //     gender :['', Validators.required],
  // //     mail: ['', Validators.compose([Validators.required, Validators.email])],
     
  // //   });
  // }

  constructor(private fb : FormBuilder) {

    let password = new FormControl(null, Validators.compose([Validators.required,Validators.pattern('^[a-zA-Z0-9]{6,10}$')]));
    let confirm_password = new FormControl(null, Validators.compose([Validators.required, Validators.pattern('^[a-zA-Z0-9]{6,10}$'),CustomValidators.equalTo(password)]));

    this.registerForm = this.fb.group({
      name :['' , Validators.required],
      bod : ['', Validators.required],
      add :['', Validators.required],
      mono  :[null, Validators.compose([Validators.required, Validators.pattern('[0-9]\\d{9}')])],
      gender :['', Validators.required],
      mail: ['', Validators.compose([Validators.required, Validators.email])],
      pass : password,
      cpass : confirm_password,
    });
   }

  ngOnInit() {
  }

  submitForm($ev, value: any) {
    for (let val in this.registerForm.controls) {
      this.registerForm.controls[val].markAsTouched();
    };
    if (this.registerForm.valid) {
      const form_data = this.registerForm.value;
      console.log(form_data);

    };
  }

}
