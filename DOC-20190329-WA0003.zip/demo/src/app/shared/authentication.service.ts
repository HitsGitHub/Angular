import { Injectable } from '@angular/core';
import { AppComponent } from '../app.component';
import { ToasterService } from 'angular2-toaster';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private toasterService : ToasterService) { }

  displayToaster(type: number, title, body?) {
    const messageType = type == 1 ? 'success' : type == 2 ? 'error' : type == 3 ? 'warning' : type == 4 ? 'info' : 'error';
    this.toasterService.pop(messageType, title, body);
  }
}
