import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthenticationService } from '../shared/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  lstData: any;

  check_validation() {

    this.loginForm = this.fb.group({
      mail: ['', Validators.compose([Validators.required, Validators.email])],
      pass: ['', Validators.required],
    });
  }
  constructor(private fb : FormBuilder , private _cS : AuthenticationService) { 
    this._cS = _cS;
  }

  ngOnInit() {
    this.check_validation();
  }
  submitForm($ev, value: any) {
    for (let val in this.loginForm.controls) {
      this.loginForm.controls[val].markAsTouched();
    };
    if (this.loginForm.valid) {
      const form_data = this.loginForm.value;
      console.log(form_data);
    };
  }

}
